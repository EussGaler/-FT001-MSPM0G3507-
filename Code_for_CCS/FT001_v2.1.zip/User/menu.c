//菜单相关
#include "menu.h"

#include "delay.h"
#include "oled.h"
#include "oscilloscope.h"
#include "DAC.h"

extern volatile uint16_t WaveType; //输出波形类别
extern volatile uint16_t Freq_Show; //显示波形的频率
extern volatile int EncoderCount; //编码器计数变化值
extern volatile uint16_t Trigger_Type; //示波器的触发方式
volatile uint16_t menu2_osc_flag = 1; //示波器二级菜单当前的选项
volatile uint16_t KeyValue; //菜单的键值

//菜单初始化
void Menu_Init(void)
{
    EncoderCount = 0; //编码器计数变化值初始化
    NVIC_ClearPendingIRQ(MENU_INT_IRQN); //清除中断标志位
    NVIC_EnableIRQ(MENU_INT_IRQN); //使能中断
    NVIC_ClearPendingIRQ(ENCODER_INT_IRQN); //清除中断标志
    NVIC_EnableIRQ(ENCODER_INT_IRQN); //使能中断
}

//第一级菜单
uint16_t menu1(void)
{
    KeyValue = 0;
    uint16_t flag = 1; //记录当前的选择

    OLED_Clear();
    DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换
    Show_Menu1(); //显示一级菜单
    OLED_Refresh();

    while (1)
    {
        if (KeyValue == 1) //选择下一项
        {
            flag ++;
            if (flag > 2)
                flag = 1;
            KeyValue = 0;
        }
        else if (KeyValue == 2) //确认
        {
            OLED_Clear(); //清屏
            OLED_Refresh();
            return flag;
        }

        switch (flag) //光标移动 
        {
            case 1:
                OLED_ShowString(3, 20, (u8 *)"*", 16, 1);
                OLED_ShowString(3, 40, (u8 *)" ", 16, 1);
                OLED_Refresh();
                break;
            case 2:
                OLED_ShowString(3, 40, (u8 *)"*", 16, 1);
                OLED_ShowString(3, 20, (u8 *)" ", 16, 1);
                OLED_Refresh();
                break;
            default:
                break;
        }
    }
}

//显示一级菜单
void Show_Menu1(void)
{
    OLED_ShowString(1, 3, (u8 *)"FT001", 8, 1);
    OLED_ShowString(50, 3, (u8 *)"by EussGaler", 8, 1);

    OLED_DrawLine(0, 15, 127, 15, 1);
    OLED_DrawLine(0, 16, 127, 16, 1);

    u16 Ch1_Array[] = {0, 2, 4, 6, 8};
    OLED_ShowMultiChinese(15, 20, Ch1_Array, 5, 16, 1); //数字示波器
    u16 Ch2_Array[] = {10, 12, 14, 16, 8};
    OLED_ShowMultiChinese(15, 40, Ch2_Array, 5, 16, 1); //波形发生器
}

//信号发生器二级菜单
uint16_t menu2_wave(void)
{
    KeyValue = 0;
    uint16_t flag = 1; //记录当前的选择

    OLED_Clear();
    DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换
    Show_Menu2_Wave(); //显示信号发生器二级菜单
    OLED_Refresh();

    while (1)
    {
        if (KeyValue == 1) //选择下一项
        {
            flag ++;
            if (flag > 3)
                flag = 1;
            KeyValue = 0;
        }
        else if (KeyValue == 2) //确认
        {
            if (flag == 3) //回到一级菜单
            {
                OLED_Clear();
                OLED_Refresh();
                return 0;
            }
        }

        switch (flag)
        {
            case 1:
                ChangeDAC_Freq(); //改变输出波形的频率

                OLED_ShowString(3, 20, (u8 *)"*", 12, 1); //光标移动
                OLED_ShowString(3, 35, (u8 *)" ", 12, 1);
                OLED_ShowString(3, 50, (u8 *)" ", 12, 1);
                OLED_Refresh();
                break;

            case 2:
                ChangeDAC_WaveType(); //改变输出波形

                OLED_ShowString(3, 20, (u8 *)" ", 12, 1);
                OLED_ShowString(3, 35, (u8 *)"*", 12, 1); //光标移动
                OLED_ShowString(3, 50, (u8 *)" ", 12, 1);
                OLED_Refresh();
                break;

            case 3:
                OLED_ShowString(3, 20, (u8 *)" ", 12, 1);
                OLED_ShowString(3, 35, (u8 *)" ", 12, 1);
                OLED_ShowString(3, 50, (u8 *)"*", 12, 1); //光标移动
                OLED_Refresh();
                break;

            default:
                break;
        }
    }
}

//显示信号发生器二级菜单
void Show_Menu2_Wave(void)
{
    OLED_ShowString(1, 3, (u8 *)"FT001", 8, 1);
    OLED_ShowString(50, 3, (u8 *)"by EussGaler", 8, 1);

    OLED_DrawLine(0, 15, 127, 15, 1);
    OLED_DrawLine(0, 16, 127, 16, 1);

    OLED_ShowString(15, 20, (u8 *)"Freq:", 12, 1);
    OLED_ShowString(15, 35, (u8 *)"Type:", 12, 1);
    OLED_ShowString(15, 50, (u8 *)"Return", 12, 1);
    
    OLED_ShowNum(70, 20, Freq_Show, 4, 12, 1);
    if (WaveType == 0)
        OLED_ShowString(70, 35, (u8 *)"Sin", 12, 1);
    else if (WaveType == 1)
        OLED_ShowString(70, 35, (u8 *)"Squ", 12, 1);
    else if (WaveType == 2)
        OLED_ShowString(70, 35, (u8 *)"Tri", 12, 1);
    else if (WaveType == 3)
        OLED_ShowString(70, 35, (u8 *)"DC ", 12, 1);
}

//示波器二级菜单
uint16_t menu2_osc(void)
{
    KeyValue = 0;
    menu2_osc_flag = 1; //记录当前的选择
    OLED_Clear();
    OLED_Refresh();
    DL_TimerG_startCounter(TIMER_REFRESH_INST); //开启ADC转换

    while (1)
    {
        if (KeyValue == 1) //选择下一项
        {
            menu2_osc_flag ++;
            if (menu2_osc_flag > 4)
                menu2_osc_flag = 1;
            KeyValue = 0;
        }
        else if (KeyValue == 2) //确认
        {
            if (menu2_osc_flag == 3) //改变触发方式
            {
                Trigger_Type ++;
                if (Trigger_Type > 1)
                    Trigger_Type = 0;
                KeyValue = 0;
            }
            else if (menu2_osc_flag == 4) //回到一级菜单
            {
                OLED_Clear();
                OLED_Refresh();
                return 0;
            }
        }

        switch (menu2_osc_flag)
        {
            case 1:
                ChangeOsc_XLevel(); //改变示波器水平档位
                break;
            case 2:
                ChangeOsc_YLevel(); //改变示波器垂直档位
                break;
            default:
                break;
        }
    }
}

//显示示波器二级菜单
void Show_Menu2_Osc(void)
{
    switch (menu2_osc_flag)
    {
        case 1:
            OLED_ShowString(100, 50, (u8 *)"X_Lv", 8, 0); //显示当前在更改水平档位
            break;
        case 2:
            OLED_ShowString(100, 50, (u8 *)"Y_Lv", 8, 0); //显示当前在更改垂直档位
            break;
        case 3:
            OLED_ShowString(100, 50, (u8 *)"MODE", 8, 0); //显示当前在更改触发模式
            break;
        case 4:
            OLED_ShowString(100, 50, (u8 *)"EXIT", 8, 0); //显示当前在选择是否退出
            break;
        default:
            break;
    }
}

//GPIO的中断服务函数
void GROUP1_IRQHandler(void)
{
    uint32_t GPIO_IIDX = DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1); //获取中断标志位
    switch (GPIO_IIDX)
    {
        case MENU_INT_IIDX: //若为GPIOB即按键
            if (DL_GPIO_readPins(MENU_PORT, MENU_PIN_1_PIN) > 0) //PB06
            {
                delay_ms(20);
                KeyValue = 1; //读取键值
                while (DL_GPIO_readPins(MENU_PORT, MENU_PIN_1_PIN)); //等待变为低电平
                delay_ms(20);
            }
            else if (DL_GPIO_readPins(MENU_PORT, MENU_PIN_2_PIN) > 0) //PB07
            {
                delay_ms(20);
                KeyValue = 2; //读取键值
                while (DL_GPIO_readPins(MENU_PORT, MENU_PIN_1_PIN)); //等待变为低电平
                delay_ms(20);
            }
            break;

        case ENCODER_INT_IIDX: //若为GPIOA即编码器
            if (DL_GPIO_readPins(ENCODER_PORT, ENCODER_ENCODER_0_PIN) == 0) //PA23
            {
                if (DL_GPIO_readPins(ENCODER_PORT, ENCODER_ENCODER_1_PIN) == 0)
                    EncoderCount ++;
                else 
                    EncoderCount --;
            }
            break;

        default:
            break;
    }
}
