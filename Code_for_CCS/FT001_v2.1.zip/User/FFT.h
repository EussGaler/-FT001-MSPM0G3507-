#ifndef __FFT_H
#define __FFT_H

#include "ti_msp_dl_config.h"

void Do_FTT(void); //FFT变换

#endif
