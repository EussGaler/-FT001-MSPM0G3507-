//ADC相关
#include "ADC.h"

#include "delay.h"
#include "oled.h"
#include "oscilloscope.h"
#include "FFT.h"
#include "menu.h"
#include "ti/driverlib/dl_adc12.h"
#include "ti/driverlib/dl_timerg.h"
#include <sys/cdefs.h>

extern volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
extern volatile uint16_t Trigger_Type; //示波器的触发方式
extern volatile uint16_t Trigger_Index; //Y-T触发模式下触发的数组下标
volatile uint16_t Trigger_Threshold; //Y-T触发模式下的触发电平，0~4095

//ADC与DMA初始化
void ADC_Init(void)
{
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC0->ULLMEM.MEMRES[0]); //设置DMA搬运的起始地址
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC_Value[0]); //设置DMA搬运的目的地址
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID); //开启DMA

    DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换
    NVIC_ClearPendingIRQ(TIMER_REFRESH_INST_INT_IRQN); //清除DMA中断标志
    NVIC_EnableIRQ(ADC_OSC_INST_INT_IRQN); //使能DMA中断

    Trigger_Threshold = 1500; //初始化Y-T触发模式下的触发电平
}

//Roll模式下DMA完成中断执行的内容
void Roll_Trigger(void)
{
    DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换

    Trigger_Index = 0;
    OLED_Clear(); //清空显示
    Oscilloscope_DrawWave(); //绘制波形
    // Do_FTT(); //FFT数据处理
    Show_Menu2_Osc(); //显示示波器二级菜单
    OLED_Refresh(); //更新显示
    delay_ms(100); //影响OLED刷新率的主要因素

    DL_TimerG_startCounter(TIMER_REFRESH_INST); //开启ADC转换
}

//Y-T上升沿触发模式下DMA完成中断执行的内容
void YT_Trigger(void)
{
    DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换

    Trigger_Index = 0;
    for (uint16_t i = 1; i < 512; i ++) //获取触发点
    { 
        //上升沿的触发条件
        if (ADC_Value[i] > Trigger_Threshold && ADC_Value[i-1] <= Trigger_Threshold)
        {
            // __BKPT(0);
            Trigger_Index = i;
            break;
        }
    }
    OLED_Clear(); //清空显示
    Oscilloscope_DrawWave(); //绘制波形
    Do_FTT(); //FFT数据处理
    Show_Menu2_Osc(); //显示示波器二级菜单
    OLED_Refresh(); //更新显示
    delay_ms(100); //影响OLED刷新率的主要因素

    DL_TimerG_startCounter(TIMER_REFRESH_INST); //开启ADC转换
}

//ADC的中断服务函数
void ADC_OSC_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC_OSC_INST)) 
    {
        case DL_ADC12_IIDX_DMA_DONE: //若为DMA搬运完成中断
            if (Trigger_Type ==0)
            {
                YT_Trigger(); //Y-T上升沿触发模式下DMA完成中断执行的内容
            }
            else if (Trigger_Type == 1)
            {
                Roll_Trigger(); //Roll模式下DMA完成中断执行的内容
            }
            break;

        default:
            break;
    }
}
