#include "ti/driverlib/dl_gpio.h"
#include "ti/driverlib/m0p/dl_core.h"
#include "ti_msp_dl_config.h"

#include <stdio.h>
#include "delay.h"
#include "oled.h"
#include "ADC.h"
#include "DAC.h"
#include "oscilloscope.h"
#include "menu.h"

volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
volatile uint16_t LoadValue; //示波器的自动重装值
volatile uint16_t WaveType; //波形类别
volatile uint16_t Freq_Show; //显示波形的频率
volatile uint16_t DAC_LoadValue_Index; //DAC更新定时器自动重装值的索引值，用于改变输出频率
volatile int EncoderCount; //编码器计数变化值
volatile uint16_t Trigger_Type; //示波器的触发方式
volatile uint16_t Trigger_Index; //Y-T触发模式下触发的数组下标
//所有GPIO的中断均放在了menu.c

int main(void)
{
    SYSCFG_DL_init(); //SYSCFG初始化
    delay_ms(50); //确保初始化完成
    OLED_Init(); //初始化OLED
    delay_ms(50); //确保初始化完成
    Menu_Init(); //初始化菜单
    delay_ms(50); //确保初始化完成
    ADC_Init(); //初始化ADC
    delay_ms(50); //确保初始化完成
    DAC_Init(); //初始化DAC 
    delay_ms(50); //确保初始化完成
    Oscilloscope_Init(); //按键中断初始化
    delay_ms(50); //确保初始化完成

    printf("FT001 by EussGaler");
    DL_GPIO_setPins(LED_PORT, LED_PIN_A14_PIN);

    uint16_t menu2; //选择的二级菜单

    while(1)
    {
        menu2 = menu1(); //获取进入哪个二级菜单
        if (menu2 == 1) //进入数字示波器二级菜单
            menu2_osc();
        else if (menu2 == 2) //进入信号发生器二级菜单
            menu2_wave();
    }
}

//防止进入意外中断Default_Handler
// void NMI_Handler(void){ __BKPT(0);} //不可屏蔽中断函数
// void HardFault_Handler(void){ __BKPT(0);} //硬件故障中断函数
// void SVC_Handler(void){ __BKPT(0);} //特权中断函数
// void PendSV_Handler(void){ __BKPT(0);} //一种可挂起的、最低优先级的中断函数
// void SysTick_Handler(void){ __BKPT(0);} //滴答定时器中断函数
// void GROUP0_IRQHandler(void){ __BKPT(0);} //GROUP0的中断函数
// // void GROUP1_IRQHandler(void){ __BKPT(0);} //GROUP1中断函数
// void TIMG8_IRQHandler(void){ __BKPT(0);} //TIMG8的中断函数
// void UART3_IRQHandler(void){ __BKPT(0);} //UART3的中断函数
// // void ADC0_IRQHandler(void){ __BKPT(0);} //ADC0的中断函数
// void ADC1_IRQHandler(void){ __BKPT(0);} //ADC1的中断函数
// void CANFD0_IRQHandler(void){ __BKPT(0);} //CANFD0的中断函数
// void DAC0_IRQHandler(void){ __BKPT(0);} //DAC0的中断函数
// void SPI0_IRQHandler(void){ __BKPT(0);} //SPI0的中断函数
// void SPI1_IRQHandler(void){ __BKPT(0);} //SPI1的中断函数
// void UART1_IRQHandler(void){ __BKPT(0);} //UART1的中断函数
// void UART2_IRQHandler(void){ __BKPT(0);} //UART2的中断函数
// void UART0_IRQHandler(void){ __BKPT(0);} //UART0的中断函数
// void TIMG0_IRQHandler(void){ __BKPT(0);} //TIMG0的中断函数
// void TIMG6_IRQHandler(void){ __BKPT(0);} //TIMG6的中断函数
// void TIMA0_IRQHandler(void){ __BKPT(0);} //TIMA0的中断函数
// void TIMA1_IRQHandler(void){ __BKPT(0);} //TIMA1的中断函数
// void TIMG7_IRQHandler(void){ __BKPT(0);} //TIMG7的中断函数
// // void TIMG12_IRQHandler(void){ __BKPT(0);} //TIMG12的中断函数
// void I2C0_IRQHandler(void){ __BKPT(0);} //I2C0的中断函数
// void I2C1_IRQHandler(void){ __BKPT(0);} //I2C1的中断函数
// void AES_IRQHandler(void){ __BKPT(0);} //硬件加速器的中断函数
// void RTC_IRQHandler(void){ __BKPT(0);} //RTC实时时钟的中断函数
// void DMA_IRQHandler(void){ __BKPT(0);} //DMA的中断函数
