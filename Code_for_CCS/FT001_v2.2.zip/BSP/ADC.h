#ifndef __ADC_H
#define __ADC_H

#include "ti_msp_dl_config.h"

void ADC_Init(void); //ADC与DMA初始化
void Roll_Trigger(void); //Roll模式下DMA完成中断执行的内容
void YT_Trigger(void); //Y-T上升沿触发模式下DMA完成中断执行的内容

#endif
