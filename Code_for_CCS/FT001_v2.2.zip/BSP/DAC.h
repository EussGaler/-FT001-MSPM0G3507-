#ifndef __DAC_H
#define __DAC_H

#include "ti_msp_dl_config.h"

void DAC_Init(void); //DAC初始化
void DAC_Update(void); //DAC更新当前输出值
void ChangeDAC_WaveType(void); //改变输出波形
void ChangeDAC_Freq(void); //改变输出波形的频率
void ChangeDAC_Vpp(void); //改变输出波形的峰值

#endif
