#ifndef __OSCILLOSCOPE_H
#define __OSCILLOSCOPE_H

#include "ti_msp_dl_config.h"

void Oscilloscope_Init(void); //按键中断初始化
void Oscilloscope_DrawXY(void); //示波器画坐标
void Oscilloscope_DrawWave(void); //绘制波形
void ChangeOsc_XLevel(void); //改变示波器水平档位
void ChangeOsc_YLevel(void); //改变示波器垂直档位

#endif
