//示波器显示相关
#include "oscilloscope.h"

#include "oled.h"
#include "delay.h"
#include "ti/driverlib/dl_timer.h"
#include "ti/driverlib/m0p/dl_interrupt.h"
#include <sys/cdefs.h>

#define LOAD_VALUE 399U //ADC采样控制定时器的自动重装值

extern volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
extern volatile uint16_t Trigger_Type; //示波器的触发方式
extern volatile uint16_t Trigger_Index; //Y-T触发模式下触发的数组下标
extern volatile int EncoderCount; //编码器计数变化值
extern volatile uint16_t LoadValue; //示波器的自动重装值
volatile double YSize = 1.0; //垂直档位

//示波器初始化
void Oscilloscope_Init(void)
{
    Trigger_Type = 0; //初始化为Y-T上升沿触发
    LoadValue = LOAD_VALUE; //自动重装值初始化
    DL_Timer_setLoadValue(TIMER_REFRESH_INST, LoadValue); //更改自动重装值
}

//示波器画坐标
void Oscilloscope_DrawXY(void)
{
    OLED_DrawLine(0, 63, 127, 63, 1); //x轴
    OLED_DrawLine(0, 16, 0, 63, 1); //y轴
    char freqStr[] = "Fq:      Hz";
    OLED_ShowString(1, 1, (u8 *)freqStr, 8, 1);
    char VppStr[] = "Vpp:    V";
    OLED_ShowString(72, 1, (u8 *)VppStr, 8, 1);
    OLED_ShowString(105, 1, (u8 *)".", 8, 1);

    for (uint8_t i = 5; i <= 127; i += 5) //画刻度
    {
        OLED_DrawPoint(i, 62, 1);
        for (uint8_t j = 57; j >= 16; j -= 5)
        {
            OLED_DrawPoint(i, j, 1);
        }
    }
    for (uint8_t j = 57; j >= 16; j -= 5) //画刻度
    {
        OLED_DrawPoint(1, j, 1);
    }
}

//绘制波形
void Oscilloscope_DrawWave(void)
{
    Oscilloscope_DrawXY();

    uint8_t ADC_Draw[128]; //绘图用的数据

    for (uint8_t i = 0; i <= 127; i ++)
    {
        //取128个数据绘图
        ADC_Draw[i] = 20 + ((ADC_Value[i + Trigger_Index] / 4095.0) * 40.0) * YSize;
        if (ADC_Draw[i] >= 62) //防止越界
            ADC_Draw[i] = 62;
    }

    for (uint8_t i = 0; i <= 126; i ++)
    {
        OLED_DrawLine(i, ADC_Draw[i], i + 1, ADC_Draw[i + 1], 1);
        OLED_DrawLine(i + 1, ADC_Draw[i + 1], i, ADC_Draw[i], 1);
    }
}

//改变示波器水平档位
void ChangeOsc_XLevel(void)
{
    // OLED_ShowNum(10, 50, (uint32_t) ((LoadValue - 399) / 600), 1, 8, 1); //显示当前自动重装值
    LoadValue = LoadValue + 600 * EncoderCount; //改变自动重装值
    EncoderCount = 0;
    if (LoadValue > 60000) //向左越界
        LoadValue = LOAD_VALUE;
    else if (LoadValue > (LOAD_VALUE + 6000)) //向右越界
        LoadValue = LOAD_VALUE + 6000;
    DL_Timer_setLoadValue(TIMER_REFRESH_INST, LoadValue); //更改自动重装值
}

//改变示波器垂直档位
void ChangeOsc_YLevel(void)
{
    YSize = YSize + 0.1 * EncoderCount; //更改垂直档位
    EncoderCount = 0;
    if (YSize < 0.3) //向左越界
        YSize = 0.3;
    else if (YSize > 2.0) //向右越界
        YSize = 2.0;
}
