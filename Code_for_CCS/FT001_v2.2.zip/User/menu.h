#ifndef __MENU_H
#define __MENU_H

#include "ti_msp_dl_config.h"

void Menu_Init(void); //菜单初始化
uint16_t menu1(void); //第一级菜单
void Show_Menu1(void); //显示一级菜单
uint16_t menu2_wave(void); //信号发生器二级菜单
void Show_Menu2_Wave(void); //显示信号发生器二级菜单
uint16_t menu2_osc(void); //示波器二级菜单
void Show_Menu2_Osc(void); //显示示波器二级菜单

#endif
