#ifndef __DAC_H
#define __DAC_H

#include "ti_msp_dl_config.h"

void DAC_Init(void); //DAC初始化
void DAC_Update(void); //DAC更新当前输出值

#endif
