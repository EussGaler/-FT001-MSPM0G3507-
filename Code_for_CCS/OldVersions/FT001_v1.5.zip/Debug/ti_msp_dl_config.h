/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000



/* Defines for TIMER_REFRESH */
#define TIMER_REFRESH_INST                                               (TIMG0)
#define TIMER_REFRESH_INST_IRQHandler                           TIMG0_IRQHandler
#define TIMER_REFRESH_INST_INT_IRQN                             (TIMG0_INT_IRQn)
#define TIMER_REFRESH_INST_LOAD_VALUE                                     (399U)
#define TIMER_REFRESH_INST_PUB_0_CH                                          (1)
/* Defines for TIMER_DAC */
#define TIMER_DAC_INST                                                  (TIMG12)
#define TIMER_DAC_INST_IRQHandler                              TIMG12_IRQHandler
#define TIMER_DAC_INST_INT_IRQN                                (TIMG12_INT_IRQn)
#define TIMER_DAC_INST_LOAD_VALUE                                         (799U)




/* Defines for ADC_OSC */
#define ADC_OSC_INST                                                        ADC0
#define ADC_OSC_INST_IRQHandler                                  ADC0_IRQHandler
#define ADC_OSC_INST_INT_IRQN                                    (ADC0_INT_IRQn)
#define ADC_OSC_ADCMEM_ADC_CH0                                DL_ADC12_MEM_IDX_0
#define ADC_OSC_ADCMEM_ADC_CH0_REF               DL_ADC12_REFERENCE_VOLTAGE_VDDA
#define ADC_OSC_ADCMEM_ADC_CH0_REF_VOLTAGE_V                                     3.3
#define ADC_OSC_INST_SUB_CH                                                  (1)
#define GPIO_ADC_OSC_C0_PORT                                               GPIOA
#define GPIO_ADC_OSC_C0_PIN                                       DL_GPIO_PIN_27



/* Defines for DMA_CH0 */
#define DMA_CH0_CHAN_ID                                                      (0)
#define ADC_OSC_INST_DMA_TRIGGER                      (DMA_ADC0_EVT_GEN_BD_TRIG)



/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOA)

/* Defines for PIN_A14: GPIOA.14 with pinCMx 36 on package pin 29 */
#define LED_PIN_A14_PIN                                         (DL_GPIO_PIN_14)
#define LED_PIN_A14_IOMUX                                        (IOMUX_PINCM36)
/* Port definition for Pin Group GPIO */
#define GPIO_PORT                                                        (GPIOA)

/* Defines for SCL: GPIOA.12 with pinCMx 34 on package pin 27 */
#define GPIO_SCL_PIN                                            (DL_GPIO_PIN_12)
#define GPIO_SCL_IOMUX                                           (IOMUX_PINCM34)
/* Defines for SDA: GPIOA.13 with pinCMx 35 on package pin 28 */
#define GPIO_SDA_PIN                                            (DL_GPIO_PIN_13)
#define GPIO_SDA_IOMUX                                           (IOMUX_PINCM35)
/* Defines for RES: GPIOA.21 with pinCMx 46 on package pin 39 */
#define GPIO_RES_PIN                                            (DL_GPIO_PIN_21)
#define GPIO_RES_IOMUX                                           (IOMUX_PINCM46)
/* Defines for DC: GPIOA.22 with pinCMx 47 on package pin 40 */
#define GPIO_DC_PIN                                             (DL_GPIO_PIN_22)
#define GPIO_DC_IOMUX                                            (IOMUX_PINCM47)
/* Defines for CS: GPIOA.2 with pinCMx 7 on package pin 8 */
#define GPIO_CS_PIN                                              (DL_GPIO_PIN_2)
#define GPIO_CS_IOMUX                                             (IOMUX_PINCM7)
/* Port definition for Pin Group OSC_KEY */
#define OSC_KEY_PORT                                                     (GPIOB)

/* Defines for PIN_X: GPIOB.2 with pinCMx 15 on package pin 14 */
// pins affected by this interrupt request:["PIN_X","PIN_Y","PIN_TRIGGER"]
#define OSC_KEY_INT_IRQN                                        (GPIOB_INT_IRQn)
#define OSC_KEY_INT_IIDX                        (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define OSC_KEY_PIN_X_IIDX                                   (DL_GPIO_IIDX_DIO2)
#define OSC_KEY_PIN_X_PIN                                        (DL_GPIO_PIN_2)
#define OSC_KEY_PIN_X_IOMUX                                      (IOMUX_PINCM15)
/* Defines for PIN_Y: GPIOB.18 with pinCMx 44 on package pin 37 */
#define OSC_KEY_PIN_Y_IIDX                                  (DL_GPIO_IIDX_DIO18)
#define OSC_KEY_PIN_Y_PIN                                       (DL_GPIO_PIN_18)
#define OSC_KEY_PIN_Y_IOMUX                                      (IOMUX_PINCM44)
/* Defines for PIN_TRIGGER: GPIOB.19 with pinCMx 45 on package pin 38 */
#define OSC_KEY_PIN_TRIGGER_IIDX                            (DL_GPIO_IIDX_DIO19)
#define OSC_KEY_PIN_TRIGGER_PIN                                 (DL_GPIO_PIN_19)
#define OSC_KEY_PIN_TRIGGER_IOMUX                                (IOMUX_PINCM45)
/* Port definition for Pin Group DAC_KEY */
#define DAC_KEY_PORT                                                     (GPIOA)

/* Defines for PIN_SWITCH: GPIOA.7 with pinCMx 14 on package pin 13 */
// pins affected by this interrupt request:["PIN_SWITCH","PIN_DAC_X"]
#define DAC_KEY_INT_IRQN                                        (GPIOA_INT_IRQn)
#define DAC_KEY_INT_IIDX                        (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define DAC_KEY_PIN_SWITCH_IIDX                              (DL_GPIO_IIDX_DIO7)
#define DAC_KEY_PIN_SWITCH_PIN                                   (DL_GPIO_PIN_7)
#define DAC_KEY_PIN_SWITCH_IOMUX                                 (IOMUX_PINCM14)
/* Defines for PIN_DAC_X: GPIOA.8 with pinCMx 19 on package pin 16 */
#define DAC_KEY_PIN_DAC_X_IIDX                               (DL_GPIO_IIDX_DIO8)
#define DAC_KEY_PIN_DAC_X_PIN                                    (DL_GPIO_PIN_8)
#define DAC_KEY_PIN_DAC_X_IOMUX                                  (IOMUX_PINCM19)





/* Defines for DAC12 */
#define DAC12_IRQHandler                                         DAC0_IRQHandler
#define DAC12_INT_IRQN                                           (DAC0_INT_IRQn)
#define GPIO_DAC12_OUT_PORT                                                GPIOA
#define GPIO_DAC12_OUT_PIN                                        DL_GPIO_PIN_15
#define GPIO_DAC12_IOMUX_OUT                                     (IOMUX_PINCM37)
#define GPIO_DAC12_IOMUX_OUT_FUNC                   IOMUX_PINCM37_PF_UNCONNECTED

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_TIMER_REFRESH_init(void);
void SYSCFG_DL_TIMER_DAC_init(void);
void SYSCFG_DL_ADC_OSC_init(void);
void SYSCFG_DL_DMA_init(void);

void SYSCFG_DL_SYSTICK_init(void);
void SYSCFG_DL_DAC12_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
