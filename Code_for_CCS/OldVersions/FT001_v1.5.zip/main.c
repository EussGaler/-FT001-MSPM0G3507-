#include "ti/driverlib/dl_gpio.h"
#include "ti/driverlib/m0p/dl_core.h"
#include "ti_msp_dl_config.h"

#include "delay.h"
#include <stdio.h>
#include "oled.h"
#include "ADC.h"
#include "DAC.h"
#include "oscilloscope.h"

volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
volatile uint16_t LoadValue_Calculate; //用于FFT计算的自动重装值
volatile uint16_t WaveType; //波形类别
volatile uint16_t DAC_LoadValue_Index; //DAC更新定时器自动重装值的索引值，用于改变输出频率
volatile uint16_t Trigger_Type; //示波器的触发方式
volatile uint16_t Start_Index; //画图时的数组起始下标
//所有GPIO的中断均放在了oscilloscope.c

int main(void)
{
    SYSCFG_DL_init(); //SYSCFG初始化

    delay_ms(50); //确保初始化完成
    OLED_Init(); //初始化OLED
    delay_ms(50); //确保初始化完成
    ADC_Init(); //初始化ADC
    delay_ms(50); //确保初始化完成
    DAC_Init(); //初始化DAC 
    delay_ms(50); //确保初始化完成
    OscilloscopeKey_Init(); //按键中断初始化
    delay_ms(50); //确保初始化完成

    Oscilloscope_DrawXY();
    OLED_Refresh(); //测试OLED

    while(1)
    {
        DL_GPIO_setPins(LED_PORT, LED_PIN_A14_PIN);
    }
}

void NMI_Handler(void){ __BKPT(0);}
void HardFault_Handler(void){ __BKPT(0);}
void SVC_Handler(void){ __BKPT(0);}
void PendSV_Handler(void){ __BKPT(0);}
void SysTick_Handler(void){ __BKPT(0);}
void GROUP0_IRQHandler(void){ __BKPT(0);}
// void GROUP1_IRQHandler(void){ __BKPT(0);}
void TIMG8_IRQHandler(void){ __BKPT(0);}
void UART3_IRQHandler(void){ __BKPT(0);}
// void ADC0_IRQHandler(void){ __BKPT(0);}
void ADC1_IRQHandler(void){ __BKPT(0);}
void CANFD0_IRQHandler(void){ __BKPT(0);}
void DAC0_IRQHandler(void){ __BKPT(0);}
void SPI0_IRQHandler(void){ __BKPT(0);}
void SPI1_IRQHandler(void){ __BKPT(0);}
void UART1_IRQHandler(void){ __BKPT(0);}
void UART2_IRQHandler(void){ __BKPT(0);}
void UART0_IRQHandler(void){ __BKPT(0);}
void TIMG0_IRQHandler(void){ __BKPT(0);}
void TIMG6_IRQHandler(void){ __BKPT(0);}
void TIMA0_IRQHandler(void){ __BKPT(0);}
void TIMA1_IRQHandler(void){ __BKPT(0);}
void TIMG7_IRQHandler(void){ __BKPT(0);}
// void TIMG12_IRQHandler(void){ __BKPT(0);}
void I2C0_IRQHandler(void){ __BKPT(0);}
void I2C1_IRQHandler(void){ __BKPT(0);}
void AES_IRQHandler(void){ __BKPT(0);}
void RTC_IRQHandler(void){ __BKPT(0);}
void DMA_IRQHandler(void){ __BKPT(0);}