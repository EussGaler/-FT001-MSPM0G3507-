#ifndef __OSCILLOSCOPE_H
#define __OSCILLOSCOPE_H

#include "ti_msp_dl_config.h"

void OscilloscopeKey_Init(void); //按键中断初始化
void Oscilloscope_DrawXY(void); //示波器画坐标
void Oscilloscope_DrawWave(void); //绘制波形
void ChangeOsc_XLevel(void); //改变示波器水平档位
void ChangeOsc_YLevel(void); //改变示波器垂直档位
void ChangeOsc_TriggerType(void); //改变示波器触发方式
void ChangeDAC_WaveType(void); //改变输出波形
void ChangeDAC_Freq(void); //改变输出波形的频率

#endif
