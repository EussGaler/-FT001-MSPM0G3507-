//FFT快速傅里叶变换相关
#include "FFT.h"

#include "stdio.h"
#include "stdlib.h"
#include "arm_math.h"
#include "oled.h"

#define FFT_LENGTH  1024
#define pi  3.1415f

extern volatile uint16_t ADC_Value[FFT_LENGTH]; //ADC转换后的数据
extern volatile uint16_t LoadValue_Calculate; //用于FFT计算的自动重装值

arm_cfft_radix4_instance_f32 scfft; //FFT实例结构体
float32_t FFT_InputBuf[FFT_LENGTH * 2]; //FFT输入数组
float32_t FFT_OutputBuf[FFT_LENGTH]; //FFT输出数组
volatile uint16_t maxindex; //最大值的索引
float32_t maxvalue; //最大值
float32_t Freq; //频率
float32_t Mag; //峰峰值
// float32_t Mag_Temp; //上一次的峰峰值
float32_t boxing; //谐波数量
uint16_t flag; //波形标识

void Do_FTT(void) //FFT变换
{
    //进行计算
    for (uint16_t i = 0; i < FFT_LENGTH; i ++)
    {
        FFT_InputBuf[2 * i] = ADC_Value[i] * 3.0f / 3600; //实部，ADC转换值
        FFT_InputBuf[2 * i + 1] = 0; //虚部，0
    }
    arm_cfft_radix4_init_f32(&scfft, FFT_LENGTH, 0, 1); //初始化，正向FFT且启用位反转
    arm_cfft_radix4_f32(&scfft, FFT_InputBuf); //执行FFT，结果覆盖FFT_InputBuf
    arm_cmplx_mag_f32(FFT_InputBuf, FFT_OutputBuf, FFT_LENGTH); //计算每个频率点的幅值，存入FFT_OutputBuf

    //找到最大值
    maxvalue = 0;
    for (uint16_t i = 2; i < FFT_LENGTH / 2; i ++)
    {
        if (FFT_OutputBuf[i] > maxvalue)
        {
            maxvalue = FFT_OutputBuf[i];
            maxindex = i;
        }
    }

    //判断波形，不精确
    boxing = FFT_OutputBuf[maxindex] / FFT_OutputBuf[3 * maxindex];
    if (maxvalue <= 0.9) //直流
    {
        OLED_ShowString(100, 50, (u8 *)"DC", 8, 1);
    }
    else if (boxing < 5 && boxing >2) //方波                          
    {
        OLED_ShowString(100, 50, (u8 *)"Squ", 8, 1);
    }    
    else if (boxing < 30 && boxing >8) //三角波                          
    {
        OLED_ShowString(100, 50, (u8 *)"Tri", 8, 1);
    }   
    else //正弦波                          
    {
        OLED_ShowString(100, 50, (u8 *)"Sin", 8, 1);
    }
    
    //计算频率及峰峰值
    //采样率为40MHz/(1+arr)，频率精度受限于FFT点数(1024)及LoadValue_Calculate
    Freq = (maxindex * (40000000.0f / (1 + LoadValue_Calculate))) / 1024.0f;
    Mag =  2 * FFT_OutputBuf[0] / FFT_LENGTH;
    // if (fabs(Mag - Mag_Temp) >= 0.09) //防止峰峰值频繁变化，设定阈值
    // {
    //     Mag_Temp = Mag;
    // }
    // else
    // {
    //     Mag = Mag_Temp;
    // }

    float32_t Mag_Show = Mag; //用于显示幅值
    if (maxvalue <= 0.9) //若为直流
    {
        Mag_Show = Mag_Show / 2.0f;
        Freq = 0;
    }
    OLED_ShowNum(20, 1, (uint32_t) Freq, 5, 8, 1); //显示频率
    OLED_ShowNum(98, 1, ((uint32_t) (Mag_Show)) % 10, 1, 8, 1); //显示峰峰值整数位
    OLED_ShowNum(110, 1, ((uint32_t) (10 * Mag_Show)) % 10, 1, 8, 1); //显示峰峰值小数位
}
