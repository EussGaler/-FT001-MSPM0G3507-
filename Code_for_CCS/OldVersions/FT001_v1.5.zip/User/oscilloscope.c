//示波器显示相关
#include "oscilloscope.h"

#include "oled.h"
#include "delay.h"
#include "ti/driverlib/dl_timer.h"
#include "ti/driverlib/m0p/dl_interrupt.h"
#include <sys/cdefs.h>

#define LOAD_VALUE 399U //ADC采样控制定时器的自动重装值

const uint16_t DAC_LoadValue[] =  //DAC更新定时器的自动重装值，长度10，<300U时会频繁中断严重影响其他程序运行
{
	799U, 399U, //对应100Hz、200Hz使用1000个数
    533U, 399U, 319U, //对应300Hz、400Hz、500Hz，使用500个数
    399U, 342U, 299U, //对应600Hz、700Hz、800Hz，使用333个数
    354U, 319U //对应900Hz、1kHz，使用250个数
};

extern volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
extern volatile uint16_t LoadValue_Calculate; //用于FFT计算的自动重装值
extern volatile uint16_t WaveType; //波形类别
extern volatile uint16_t DAC_LoadValue_Index; //DAC更新定时器自动重装值的索引值，用于改变输出频率
extern volatile uint16_t Trigger_Type; //示波器的触发方式
extern volatile uint16_t Start_Index; //画图时的数组起始下标
volatile uint16_t LoadValue; //自动重装值
volatile double YSize = 1.0; //垂直档位
volatile uint16_t XSize = 1; //水平档位

//按键中断初始化
void OscilloscopeKey_Init(void)
{
    NVIC_ClearPendingIRQ(OSC_KEY_INT_IRQN); //清除GPIOB中断标志
    NVIC_EnableIRQ(OSC_KEY_INT_IRQN); //使能GPIOB中断

    Trigger_Type = 1; //初始化为Y-T上升沿触发
    WaveType = 0; //输出波形类别初始化
    DAC_LoadValue_Index = 0; //初始化自动重装值的索引值
    LoadValue = LOAD_VALUE; //自动重装值初始化
    LoadValue_Calculate = LOAD_VALUE; //自动重装值计算初始化
    DL_Timer_setLoadValue(TIMER_REFRESH_INST, LoadValue); //更改自动重装值
}

//示波器画坐标
void Oscilloscope_DrawXY(void)
{
    OLED_DrawLine(0, 63, 127, 63, 1); //x轴
    OLED_DrawLine(0, 16, 0, 63, 1); //y轴
    char freqStr[] = "Fq:      Hz";
    OLED_ShowString(1, 1, (u8 *)freqStr, 8, 1);
    char VppStr[] = "Vpp:    V";
    OLED_ShowString(72, 1, (u8 *)VppStr, 8, 1);
    OLED_ShowString(105, 1, (u8 *)".", 8, 1);

    for (uint8_t i = 5; i <= 127; i += 5) //画刻度
    {
        OLED_DrawPoint(i, 62, 1);
        for (uint8_t j = 57; j >= 16; j -= 5)
        {
            OLED_DrawPoint(i, j, 1);
        }
    }
    for (uint8_t j = 57; j >= 16; j -= 5) //画刻度
    {
        OLED_DrawPoint(1, j, 1);
    }
}

//绘制波形
void Oscilloscope_DrawWave(void)
{
    Oscilloscope_DrawXY();

    uint8_t ADC_Draw[128]; //绘图用的数据

    for (uint8_t i = Start_Index; i <= (Start_Index + 127); i ++)
    {
        //取128个数据绘图
        ADC_Draw[i] = 20 * (2.0 - YSize) + ((ADC_Value[i * XSize] / 4095.0) * 40.0) * YSize;
    }

    for (uint8_t i = 0; i <= 126; i ++)
    {
        OLED_DrawLine(i, ADC_Draw[i], i + 1, ADC_Draw[i + 1], 1);
        OLED_DrawLine(i + 1, ADC_Draw[i + 1], i, ADC_Draw[i], 1);
    }
}

//改变示波器水平档位
void ChangeOsc_XLevel(void)
{
    DL_Timer_setLoadValue(TIMER_REFRESH_INST, LoadValue); //更改自动重装值
    OLED_ShowNum(10, 50, (uint32_t) ((LoadValue - 399) / 600), 1, 8, 1); //显示当前自动重装值
    OLED_Refresh();
    LoadValue_Calculate = LoadValue; //保存改变前的自动重装值
    LoadValue += 600; //改变自动重装值
    if (LoadValue >= (LOAD_VALUE + 6000))
    {
        LoadValue = LOAD_VALUE;
    }
    delay_ms(500);
}

//改变示波器垂直档位
void ChangeOsc_YLevel(void)
{
    YSize -= 0.1; //更改垂直档位
    if (YSize < 0.5)
    {
        YSize = 1.0;
    }
    OLED_ShowNum(10, 50, (uint32_t) (10 * YSize), 2, 8, 1); //显示垂直档位
    OLED_Refresh();
    delay_ms(500);
}

//改变示波器触发方式
void ChangeOsc_TriggerType(void)
{
    Trigger_Type += 1; //更改示波器触发方式
    if (Trigger_Type >= 2)
    {
        Trigger_Type = 0;
    }
    OLED_ShowNum(10, 50, (uint32_t) Trigger_Type, 1, 8, 1); //显示示波器触发方式
    OLED_Refresh();
    delay_ms(500);
}

//改变输出波形
void ChangeDAC_WaveType(void)
{
    WaveType += 1; //更改波形类别，0/1/2/3为正弦/方波/三角/直流
    if (WaveType >= 4)
    {
        WaveType = 0;
    }
}

//改变输出波形的频率
void ChangeDAC_Freq(void)
{
    DAC_LoadValue_Index += 1; //更改输出波形的频率
    if (DAC_LoadValue_Index >= 10)
    {
        DAC_LoadValue_Index = 0;
    }
    DL_Timer_setLoadValue(TIMER_DAC_INST, DAC_LoadValue[DAC_LoadValue_Index]);
}

//GPIO的中断服务函数
void GROUP1_IRQHandler(void)
{
    uint32_t GPIO_IIDX = DL_Interrupt_getPendingGroup(DL_INTERRUPT_GROUP_1); //获取中断标志位
    switch (GPIO_IIDX)
    {
        case OSC_KEY_INT_IIDX: //若为GPIOB的中断
            if (DL_GPIO_readPins(OSC_KEY_PORT, OSC_KEY_PIN_X_PIN) > 0) //判断PB02引脚是否为高电平
            {
                ChangeOsc_XLevel(); //改变示波器水平档位
            }
            else if (DL_GPIO_readPins(OSC_KEY_PORT, OSC_KEY_PIN_Y_PIN) > 0) //判断PB18引脚是否为高电平
            {
                ChangeOsc_YLevel(); //改变示波器垂直档位
            }
            else if (DL_GPIO_readPins(OSC_KEY_PORT, OSC_KEY_PIN_TRIGGER_PIN) > 0) //判断PB19引脚是否为高电平
            {
                ChangeOsc_TriggerType(); //改变示波器触发方式
            }
            break;

        case DAC_KEY_INT_IIDX: //若为GPIOA的中断
            if (DL_GPIO_readPins(DAC_KEY_PORT, DAC_KEY_PIN_SWITCH_PIN) > 0) //判断PA07引脚是否为高电平
            {
                delay_ms(20);
                ChangeDAC_WaveType(); //改变输出波形
                while (DL_GPIO_readPins(DAC_KEY_PORT, DAC_KEY_PIN_SWITCH_PIN)); //等待变为低电平
                delay_ms(20);
            }
            else if (DL_GPIO_readPins(DAC_KEY_PORT, DAC_KEY_PIN_DAC_X_PIN) > 0) //判断PA08引脚是否为高电平
            {
                delay_ms(20);
                ChangeDAC_Freq(); //改变输出波形的频率
                while (DL_GPIO_readPins(DAC_KEY_PORT, DAC_KEY_PIN_DAC_X_PIN)); //等待变为低电平
                delay_ms(20);
            }
            break;

        default:
            break;
    }
}
