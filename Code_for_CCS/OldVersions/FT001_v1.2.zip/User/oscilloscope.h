#ifndef __OSCILLOSCOPE_H
#define __OSCILLOSCOPE_H

#include "ti_msp_dl_config.h"

void OscilloscopeKey_Init(void); //按键中断初始化
void Oscilloscope_DrawXY(void); //示波器画坐标
void Oscilloscope_DrawWave(void); //绘制波形

#endif
