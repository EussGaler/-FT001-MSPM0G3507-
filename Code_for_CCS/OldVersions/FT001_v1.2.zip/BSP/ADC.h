#ifndef __ADC_H
#define __ADC_H

#include "ti_msp_dl_config.h"

void ADC_Init(void);

#endif
