#include "ADC.h"

#include "delay.h"
#include "oled.h"
#include "oscilloscope.h"
#include "FFT.h"
#include "ti/driverlib/dl_adc12.h"
#include "ti/driverlib/dl_timerg.h"

extern volatile uint16_t ADC_Value[1024]; //ADC转换后的数据

void ADC_Init(void)
{
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC0->ULLMEM.MEMRES[0]); //设置DMA搬运的起始地址
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC_Value[0]); //设置DMA搬运的目的地址
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID); //开启DMA

    NVIC_ClearPendingIRQ(TIMER_REFRESH_INST_INT_IRQN); //清除DMA中断标志
    NVIC_EnableIRQ(ADC_OSC_INST_INT_IRQN); //使能DMA中断
}

void ADC_OSC_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC_OSC_INST)) 
    {
        case DL_ADC12_IIDX_DMA_DONE: //若为DMA搬运完成中断
            DL_TimerG_stopCounter(TIMER_REFRESH_INST); //暂停计时即停止ADC转换

            OLED_Clear(); //清空显示内容
            Oscilloscope_DrawWave(); //绘制波形
            Do_FTT(); //FFT数据处理
            OLED_Refresh(); //刷新显示屏
            delay_ms(300);

            DL_TimerG_startCounter(TIMER_REFRESH_INST); //开启ADC转换
            break;

        default:
            break;
    }
}
