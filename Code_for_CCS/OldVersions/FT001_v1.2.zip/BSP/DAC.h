#ifndef __DAC_H
#define __DAC_H

#include "ti_msp_dl_config.h"

void DAC_Init(void); 

#endif
