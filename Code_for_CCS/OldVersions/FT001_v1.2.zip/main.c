#include "ti/driverlib/dl_gpio.h"
#include "ti/driverlib/m0p/dl_core.h"
#include "ti_msp_dl_config.h"

#include "delay.h"
#include <stdio.h>
#include "oled.h"
#include "ADC.h"
#include "DAC.h"
#include "oscilloscope.h"

volatile uint16_t ADC_Value[1024]; //ADC转换后的数据
volatile uint16_t LoadValue_Calculate; //用于FFT计算的自动重装值

int main(void)
{
    SYSCFG_DL_init(); //SYSCFG初始化
    delay_ms(50); //确保OLED初始化完成
    OLED_Init(); //初始化OLED
    ADC_Init(); //初始化ADC
    DAC_Init(); //初始化DAC 
    OscilloscopeKey_Init(); //按键中断初始化

    Oscilloscope_DrawXY();
    OLED_Refresh(); //测试OLED

    while(1)
    {
        DL_GPIO_togglePins(LED_PORT, LED_PIN_A14_PIN);
        delay_ms(500);
    }
}
